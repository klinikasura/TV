<?php
session_start();
require_once 'config.php';
require_once 'includes.php';

// Pastikan user sudah login
if (!isset($_SESSION['user_id'])) {
    header('Location: http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/LOG/login.php');
    exit;
}

// Ambil data user berdasarkan ID di session
$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM robot80_data_anggota WHERE id=$user_id";
$result = $mysqli->query($query);
$user = $result->fetch_assoc();

update_user_activity($user_id);
?>


<html>
	<head>
          <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
          <title>Aplikasi RS. Asura</title>
        <link href="http://10.10.20.250/dashboard/download.jpeg" rel="icon" type="image/png"

    <!-- Include file CSS Bootstrap -->
    <link href="http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/DATA-CYBER-2/FARMASI/TAMPIL-OBAT-ED/css/bootstrap.min.css" rel="stylesheet">

    <!-- Include library Bootstrap Datepicker -->
    <link href="http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/DATA-CYBER-2/FARMASI/TAMPIL-OBAT-ED/libraries/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet">
<meta http-equiv="refresh" content="0;url=http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/OBAT-STOK/index-harga-obat.php"/> 

 <link rel="stylesheet" href="http://10.10.20.250/dashboard/APPS-ROBOT/assets/css/vendor.css">
    <link rel="stylesheet" href="http://10.10.20.250/dashboard/APPS-ROBOT/assets/css/style.css">
    <link rel="stylesheet" href="http://10.10.20.250/dashboard/APPS-ROBOT/assets/css/responsive.css">
  <script src="http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/DATA-CYBER-2/FARMASI/TAMPIL-OBAT-ED/js/jquery.min.js"></script>
	</head>
<audio autoplay>
    <source src="CEK2.mp3" type="audio/mpeg">
    </audio>


	<body>




<?php
			include "koneksi.php";
			$sekarang	=date("d-m-Y");
		?>

        <p>&nbsp;</p>



<center><font color="red"><h8><?php
// 1. Dapatkan tanggal dari input pengguna (misalnya dari form) atau gunakan tanggal saat ini
$tanggal_input = isset($_GET['expire']) ? $_GET['expire'] : date("Y-m-d");

// 2. Hubungkan ke database (contoh menggunakan MySQLi)
$host = "10.10.20.250";
$username = "root";
$password = "";
$database = "sikdraisyah";

$koneksi = new mysqli($host, $username, $password, $database);

// Periksa koneksi
if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
}

// 3. Bangun query SQL dengan klausa WHERE
$query = "SELECT * FROM databarang WHERE expire = '$tanggal_input'";

// Contoh lain dengan BETWEEN:
// $query = "SELECT * FROM nama_tabel WHERE tanggal_kolom BETWEEN '$tanggal_awal' AND '$tanggal_akhir'";

// 4. Eksekusi query
$hasil = $koneksi->query($query);

// 5. Tampilkan hasil (contoh sederhana)
if ($hasil->num_rows > 0) {
    while($row = $hasil->fetch_assoc()) {
        echo "PEMERITAHUAN OBAT KADALUARSA !!!! : " . " (" . $row["nama_brng"]. " -  Apotik : " . $row["isi"]." - Gudang : " . $row["stokminimal"].  " - Tanggal : " . $row["expire"].")" ." <p> " . "<br>";
    }
} else {
    echo "Horee.... Tidak Ada Obat Kadaluarsa.";
}

// Tutup koneksi
$koneksi->close();
?></h3></font></center>
<p>


	<font color="green"><center><p>Hari ini Tanggal: <?php echo $sekarang?></p></center>

<center>
<form action="" method="post">
    <input type="text" name="keyword" placeholder="Cari Nama Obat & BHP / Tahun">
    <button type="submit" name="cari" >Cari</button></center>

<center><a href="http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/DATA-CYBER-2/FARMASI/HARGA-OBAT-FARMASI-2/index2.php"  >Obat & BHP Tidak di Temukan, Klik<i class="fa fa-book"></i></a>
</form>

<?php
// Koneksi database
$conn = mysqli_connect("10.10.20.250", "root", "", "sikdraisyah");

// Periksa koneksi
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Tanggal sekarang
$sekarang = date("Y-m-d");

// Fungsi pencarian
if (isset($_POST['cari'])) {
    $keyword = $_POST['keyword'];
    $query = mysqli_query($conn, "SELECT * FROM databarang WHERE (nama_brng LIKE '%$keyword%' OR expire LIKE '%$keyword%') AND status = '1' AND expire > '$sekarang' ORDER BY expire");
} else {
    $query = mysqli_query($conn, "SELECT * FROM databarang WHERE status = '1' AND expire > '$sekarang' ORDER BY expire");
}

// Tampilkan tabel
$no = 1;
?>
<font color="green"><p>====>  Menampilkan Berdasarkan Tanggal Kadaluarsa & Harga yang di Input 
		  <div class="table-responsive" style="margin-top: 10px;">
            <table class="table table-bordered">
                <thead>
				<tr bgcolor="#E5E5E5">
       <td>No</td>
					<td>Kode Obat / BHP</td>
					<td>Nama Obat / BHP</td>
					<td>Tanggal Kadaluarsa</td>
					<td>Harga Karyawan</td>
					<td>Harga Ralan</td>




    </tr>
    <?php while ($row = mysqli_fetch_assoc($query)) { ?>
    <tr>
        <td><?php echo $no++; ?></td>
<td><?php echo $row['kode_brng']; ?></td>
        <td><?php echo $row['nama_brng']; ?></td>
        <td><?php echo $row['expire']; ?></td>
        <td><?php echo $row['karyawan']; ?></td>
 <td><?php echo $row['ralan']; ?></td>
    </tr>
    <?php } ?>
</table>






 <div class="footer-area">
        <div class="" style="">
            <div class="">
                
            </div>
        </div>






<p>   <p>&nbsp;</p>




  <!-- Footer Area -->
    
            <h1><div class="footer-bottom text-center">
                <ul>
                    <li>
                        <a href="http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/index-dashboard2-farmasi.php">
<img border="0" src="http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/FILE/BERANDA.png"  height="45" width="45" /></a>
                            <i class=""></i>
                            <p>Beranda</p>
                        </a>
                    </li>
                    <li>
                        <a href="http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/index-dashboard-2-2.html">
<img border="0" src="http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/FILE/SATUSEHAT-INTEGRASI-VERSI-80-2.png"  height="50" width="50" /></a>
                            <i class=""></i>
                            <p>ASKES</p>
                        </a>
                    </li>
                    <li>
                        <a href="http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/WIDGET/NEW/AI-BACA-BARCODE-2">
<img border="0" src="http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/SCANRM2.webp"  height="45" width="45" /></a>
                            <i class=""></i>
                            <p>SCAN RM</p>
                        </a>
                    </li>
                    <li>
                        <a href="http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/index-dashboard-Playstore.html">
<img border="0" src="http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/FILE/PLAYSTORE.png"  height="45" width="45" /></a>
                            <i class=""></i>
                            <p>PLAYSTORE</p>
                        </a>
                    </li>
                    <li>
                        <a href="http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/logout2.php">
<img border="0" src="http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/LOGOUT.webp"  height="45" width="45" /></a>
                            <i class=""></i>
                            <p>LOGOUT</p>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
</div>









	</body>
</html>


