<?php
// Koneksi database
$conn = mysqli_connect("localhost", "username", "password", "database");

// Periksa koneksi
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Tanggal sekarang
$sekarang = date("Y-m-d");

// Jumlah data per halaman
$limit = 10;

// Fungsi pencarian
if (isset($_POST['cari'])) {
    $keyword = $_POST['keyword'];
    $query = "SELECT * FROM databarang WHERE (nama LIKE '%$keyword%' OR deskripsi LIKE '%$keyword%') AND status = '1' AND expire > '$sekarang'";
} else {
    $query = "SELECT * FROM databarang WHERE status = '1' AND expire > '$sekarang'";
}

// Hitung jumlah data
$result = mysqli_query($conn, $query);
$total_data = mysqli_num_rows($result);

// Hitung jumlah halaman
$total_halaman = ceil($total_data / $limit);

// Tentukan halaman saat ini
if (isset($_GET['halaman'])) {
    $halaman = $_GET['halaman'];
} else {
    $halaman = 1;
}

// Hitung offset
$offset = ($halaman - 1) * $limit;

// Query dengan paging
if (isset($_POST['cari'])) {
    $query_paging = "SELECT * FROM databarang WHERE (nama LIKE '%$keyword%' OR deskripsi LIKE '%$keyword%') AND status = '1' AND expire > '$sekarang' ORDER BY expire LIMIT $offset, $limit";
} else {
    $query_paging = "SELECT * FROM databarang WHERE status = '1' AND expire > '$sekarang' ORDER BY expire LIMIT $offset, $limit";
}

$result_paging = mysqli_query($conn, $query_paging);

// Tampilkan tabel
$no = ($halaman - 1) * $limit + 1;
?>
<table>
    <tr>
        <th>No.</th>
        <th>Nama</th>
        <th>Deskripsi</th>
        <th>Expire</th>
    </tr>
    <?php while ($row = mysqli_fetch_assoc($result_paging)) { ?>
    <tr>
        <td><?php echo $no++; ?></td>
        <td><?php echo $row['nama']; ?></td>
        <td><?php echo $row['deskripsi']; ?></td>
        <td><?php echo $row['expire']; ?></td>
    </tr>
    <?php } ?>
</table>

// Paging
<?php for ($i = 1; $i <= $total_halaman; $i++) { ?>
    <?php if ($i == $halaman) { ?>
        <span><?php echo $i; ?></span>
    <?php } else { ?>
        <a href="?halaman=<?php echo $i; ?>"><?php echo $i; ?></a>
    <?php } ?>
<?php } ?>

// Form pencarian
<form action="" method="post">
    <input type="text" name="keyword" placeholder="Cari...">
    <button type="submit" name="cari">Cari</button>
</form>
