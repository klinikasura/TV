<?php 
 
// https://www.malasngoding.com
// koneksi database
$koneksi = mysqli_connect('10.10.20.250','root','','sikdraisyah');
 
?>
