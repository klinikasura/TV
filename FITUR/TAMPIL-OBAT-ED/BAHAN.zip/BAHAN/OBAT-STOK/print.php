<?php
session_start();
require_once 'config.php';
require_once 'includes.php';

// Pastikan user sudah login
if (!isset($_SESSION['user_id'])) {
    header('Location: http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/LOG/login.php');
    exit;
}

// Ambil data user berdasarkan ID di session
$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM robot80_data_anggota WHERE id=$user_id";
$result = $mysqli->query($query);
$user = $result->fetch_assoc();

update_user_activity($user_id);
?>


<p>
Di Cetak Oleh Petugas : <?= $user['nama']; ?> (<?= $user['posisi']; ?>)</p>

<?php
date_default_timezone_set('Asia/Jakarta'); // Set zona waktu
$hari = array("Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu");
$bulan = array("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember");

$hari_ini = $hari[date("w")];
$tanggal = date("d");
$bulan_ini = $bulan[date("n") - 1];
$tahun = date("Y");

$jam_sekarang = date("H:i:s"); // Format jam

echo "Hari ini: $hari_ini, $tanggal $bulan_ini $tahun<br>";
echo "Jam sekarang: $jam_sekarang";
?>

<p>
<center><h2>Laporan Daftar Obat Instalasi Farmasi</h2></center>
<p>

<?php 
$servername = "10.10.20.250"; 
$username = "root"; 
$password = ""; 
$dbname = "sikdraisyah"; 

// Buat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$tgl_awal = $_GET['tgl_awal'];
$tgl_akhir = $_GET['tgl_akhir'];
$kd_bangsal = $_GET['kd_bangsal'];

$query = "
    SELECT 
        gb.kode_brng, 
        d.nama_brng, 
        d.expire,
  d.ralan,
  d.karyawan,
        gb.kd_bangsal, 
        b.nm_bangsal, 
        gb.stok
    FROM 
        gudangbarang gb
        INNER JOIN databarang d ON gb.kode_brng = d.kode_brng
        INNER JOIN bangsal b ON gb.kd_bangsal = b.kd_bangsal
    WHERE 
        d.status = '1'
";

if (!empty($tgl_awal) && !empty($tgl_akhir)) {
    $query .= " AND d.expire BETWEEN '$tgl_awal' AND '$tgl_akhir'";
}

if (!empty($kd_bangsal)) {
    $query .= " AND gb.kd_bangsal = '$kd_bangsal'";
}

$result = $conn->query($query);

header("Content-type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=laporan_obat_$tgl_awal-$tgl_akhir.xls");

echo "<table border='1'>";
echo "<tr><th>No</th><th>Kode Barang</th><th>Nama Obat & BHP</th><th>Tgl Kadaluarsa</th><th>Harga Ralan</th><th>Harga Karyawan</th><th>Kode Asal</th><th>Nama Asal Stok</th><th>Stok Real</th></tr>";
$no = 1;
while($row = $result->fetch_assoc()) {
    echo "<tr>";
    echo "<td>" . $no . "</td>";
    echo "<td>" . $row["kode_brng"] . "</td>";
    echo "<td>" . $row["nama_brng"] . "</td>";
    echo "<td>" . $row["expire"] . "</td>";
 echo "<td>" . $row["ralan"] . "</td>";
 echo "<td>" . $row["karyawan"] . "</td>";
    echo "<td>" . $row["kd_bangsal"] . "</td>";
    echo "<td>" . $row["nm_bangsal"] . "</td>";
    echo "<td>" . $row["stok"] . "</td>";
    echo "</tr>";
    $no++;
}
echo "</table>";

$conn->close();
?>
