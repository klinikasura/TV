<?php
$conn = mysqli_connect("10.10.20.250", "root", "", "sikdraisyah");

if (!$conn) {
    die("Koneksi gagal : " . mysqli_connect_error());
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Laporan Stok Obat & ED</title>

<style>

body{
    font-family:Segoe UI, Arial, sans-serif;
    background:#eaf6ff;
    margin:0;
    padding:20px;
    color:#0d2b45;
}

/* ===============================
   HEADER
================================= */

.judul{
    text-align:center;
    background:linear-gradient(45deg,#4fc3f7,#0288d1);
    color:white;
    padding:20px;
    border-radius:15px;
    margin-bottom:20px;
    box-shadow:0 5px 15px rgba(0,0,0,0.1);
}

/* ===============================
   FILTER
================================= */

.filter-box{
    background:white;
    padding:20px;
    border-radius:15px;
    margin-bottom:20px;
    box-shadow:0 5px 15px rgba(0,0,0,0.08);
}

.filter-box form{
    display:flex;
    flex-wrap:wrap;
    gap:10px;
    align-items:center;
}

.filter-box select,
.filter-box input{
    padding:10px;
    border:1px solid #90caf9;
    border-radius:10px;
    outline:none;
}

.filter-box button{
    background:linear-gradient(45deg,#29b6f6,#0288d1);
    color:white;
    border:none;
    padding:10px 18px;
    border-radius:10px;
    cursor:pointer;
    font-weight:bold;
}

.filter-box button:hover{
    opacity:0.9;
}

/* ===============================
   TABLE
================================= */

table{
    width:100%;
    border-collapse:collapse;
    background:white;
    border-radius:15px;
    overflow:hidden;
    box-shadow:0 5px 15px rgba(0,0,0,0.08);
}

th{
    background:#0288d1;
    color:white;
    padding:12px;
    font-size:14px;
}

td{
    padding:10px;
    border-bottom:1px solid #e3f2fd;
    text-align:center;
    font-size:14px;
}

tr:nth-child(even){
    background:#f5fbff;
}

tr:hover{
    background:#e1f5fe;
}

/* ===============================
   GROUPING BANGSAL
================================= */

.group-title td{
    background:#01579b !important;
    color:white;
    font-weight:bold;
    text-align:left;
    font-size:15px;
    padding:12px;
}

/* ===============================
   WARNA IGD / FARMASI
================================= */

.igd{
    background:#ffebee !important;
    color:#b71c1c;
    font-weight:bold;
}

/* ===============================
   STOK MINIMUM
================================= */

.stok-tipis{
    background:#fff3cd !important;
    color:#856404;
    font-weight:bold;
}

/* ===============================
   PRINT
================================= */

@media print{

    body{
        background:white;
        padding:0;
    }

    .filter-box{
        display:none;
    }

    .judul{
        box-shadow:none;
    }

    table{
        box-shadow:none;
    }

    th{
        background:#0288d1 !important;
        -webkit-print-color-adjust:exact;
    }

}

</style>
</head>

<body>

<div class="judul">
    <h2>LAPORAN STOK OBAT & EXPIRED DATE</h2>
    <p>SIMRS FARMASI</p>
</div>

<div class="filter-box">

<form method="POST">

<select name="kd_bangsal">

<option value="">-- Semua Bangsal --</option>

<?php
$bangsal = mysqli_query($conn, "SELECT * FROM bangsal ORDER BY nm_bangsal");

while($b = mysqli_fetch_assoc($bangsal)){

echo "<option value='".$b['kd_bangsal']."'>
".$b['nm_bangsal']."
</option>";

}
?>

</select>

<input type="text" name="nama_obat" placeholder="Cari Nama Obat">

<input type="date" name="tgl_awal">

<input type="date" name="tgl_akhir">

<button type="submit" name="cari">
🔍 Cari
</button>

<button type="button" onclick="window.print()">
🖨 Print
</button>

</form>

</div>

<?php

if(isset($_POST['cari'])){

$kd_bangsal = $_POST['kd_bangsal'];
$nama_obat = $_POST['nama_obat'];
$tgl_awal = $_POST['tgl_awal'];
$tgl_akhir = $_POST['tgl_akhir'];

$query = "
SELECT
    gb.kode_brng,
    d.nama_brng,
    d.expire,
    gb.kd_bangsal,
    b.nm_bangsal AS asal_stok,
    gb.stok
FROM gudangbarang gb

INNER JOIN databarang d
ON gb.kode_brng = d.kode_brng

INNER JOIN bangsal b
ON gb.kd_bangsal = b.kd_bangsal

WHERE d.status='1'
";

/* =========================
   FILTER
========================= */

if(!empty($kd_bangsal)){
    $query .= " AND gb.kd_bangsal='$kd_bangsal'";
}

if(!empty($nama_obat)){
    $query .= " AND d.nama_brng LIKE '%$nama_obat%'";
}

if(!empty($tgl_awal) && !empty($tgl_akhir)){
    $query .= " AND d.expire BETWEEN '$tgl_awal' AND '$tgl_akhir'";
}

$query .= " ORDER BY b.nm_bangsal, d.expire ASC";

$result = mysqli_query($conn, $query);

if(mysqli_num_rows($result) > 0){

echo "<table>";

echo "
<tr>
<th>No</th>
<th>Kode Barang</th>
<th>Nama Obat</th>
<th>Expired</th>
<th>Kode Asal</th>
<th>Asal Stok</th>
<th>Stok</th>
</tr>
";

$no = 1;
$current_bangsal = "";

while($row = mysqli_fetch_assoc($result)){

/* =========================
   GROUPING PER BANGSAL
========================= */

if($current_bangsal != $row['asal_stok']){

$current_bangsal = $row['asal_stok'];

echo "
<tr class='group-title'>
<td colspan='7'>
🏥 ".$current_bangsal."
</td>
</tr>
";

}

/* =========================
   WARNA BARIS
========================= */

$class = "";

/* 🔴 IGD / FARMASI */
if(
    stripos($row['asal_stok'], 'IGD') !== false ||
    stripos($row['asal_stok'], 'FARMASI') !== false
){
    $class = "igd";
}

/* 🟡 STOK TIPIS */
if($row['stok'] <= 10){
    $class = "stok-tipis";
}

echo "<tr class='$class'>";

echo "<td>".$no."</td>";

echo "<td>".$row['kode_brng']."</td>";

echo "<td style='text-align:left'>
".$row['nama_brng']."
</td>";

echo "<td>".$row['expire']."</td>";

echo "<td>".$row['kd_bangsal']."</td>";

echo "<td>
<b>🏥 ".$row['asal_stok']."</b>
</td>";

echo "<td>
<b>".$row['stok']."</b>
</td>";

echo "</tr>";

$no++;

}

echo "</table>";

}else{

echo "
<div style='
background:white;
padding:20px;
border-radius:10px;
text-align:center;
box-shadow:0 5px 15px rgba(0,0,0,0.08);
'>
❌ Data tidak ditemukan
</div>
";

}

}

mysqli_close($conn);

?>

</body>
</html>
