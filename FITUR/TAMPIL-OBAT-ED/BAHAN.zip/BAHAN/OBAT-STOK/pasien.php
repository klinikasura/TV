<?php
session_start();
require_once 'config.php';
require_once 'includes.php';

// Pastikan user sudah login
if (!isset($_SESSION['user_id'])) {
    header('Location: http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/LOG/login.php');
    exit;
}

// Ambil data user berdasarkan ID di session
$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM robot80_data_anggota WHERE id=$user_id";
$result = $mysqli->query($query);
$user = $result->fetch_assoc();

update_user_activity($user_id);
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <link href="http://10.10.20.250/dashboard/download.jpeg" rel="icon" type="image/png" />

   <!-- Include file CSS Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Include library Bootstrap Datepicker -->
    <link href="libraries/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet">


 <link rel="stylesheet" href="http://10.10.20.250/dashboard/APPS-ROBOT/assets/css/vendor.css">
    <link rel="stylesheet" href="http://10.10.20.250/dashboard/APPS-ROBOT/assets/css/style.css">
    <link rel="stylesheet" href="http://10.10.20.250/dashboard/APPS-ROBOT/assets/css/responsive.css">


  <title>Aplikasi RS. Asura</title>
</head>


   
        
<audio autoplay>
    <source src="PASIEN.mp3" type="audio/mpeg">
    </audio>


              


<p>   <p>&nbsp;</p>
   <div class="footer-area">
        <div class="" style="">
            <div class="">
                
            </div>
        </div>

<?php
 
// menghubungkan dengan koneksi database
include 'koneksi2.php';
 
// mengambil data barang
$data_barang = mysqli_query($koneksi,"SELECT * FROM pasien");
 
// menghitung data barang
$jumlah_barang = mysqli_num_rows($data_barang);
?>
        <?php 
            $servername     = "10.10.20.250";
            $database       = "sikdraisyah";
            $username       = "root";
            $password       = "";
    
            // membuat koneksi
            $conn = mysqli_connect($servername, $username, $password, $database);
        ?>



 <p>Jumlah Seluruh Data Pasien : <b><?php echo $jumlah_barang; ?></b></p>


<body>
  <form action="" method="post">
    <label>Tanggal Awal:</label>
    <input type="date" name="tgl_awal"><br><br>
    <label>Tanggal Akhir:</label>
    <input type="date" name="tgl_akhir"><br><br>
    <label>Nama Pasien :</label>
    <input type="text" name="nm_pasien" placeholder="Masukan Nama Pasien "><br><br>
    <input type="submit" name="cari" value="Cari / Tampilkan Data">

  </form>


     <div class="table-responsive" style="margin-top: 10px;">
            <table class="table table-bordered">
                <thead>



  <?php
  $servername = "10.10.20.250";
  $username = "root";
  $password = "";
  $dbname = "sikdraisyah";

  // Buat koneksi
  $conn = new mysqli($servername, $username, $password, $dbname);

  // Cek koneksi
  if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
  }

  if(isset($_POST['cari'])) {
    $tgl_awal = $_POST['tgl_awal'];
    $tgl_akhir = $_POST['tgl_akhir'];
    $nm_pasien = $_POST['nm_pasien'];

    if ($tgl_awal == '' && $tgl_akhir == '' && $nm_pasien == '') {
      $query = "SELECT no_rkm_medis, nm_pasien, no_ktp, jk, alamat, tgl_daftar FROM pasien";
    } else {
      $query = "SELECT no_rkm_medis, nm_pasien, no_ktp, jk, alamat, tgl_daftar 
                FROM pasien 
                WHERE (tgl_daftar BETWEEN '$tgl_awal' AND '$tgl_akhir' OR '$tgl_awal' = '' OR '$tgl_akhir' = '') 
                AND (nm_pasien LIKE '%$nm_pasien%' OR '$nm_pasien' = '')";
    }
  } else {
    $query = "SELECT no_rkm_medis, nm_pasien, no_ktp, jk, alamat, tgl_daftar FROM pasien";
  }

  $result = $conn->query($query);

  if ($result->num_rows > 0) {
    echo "<h2>Data Master Pasien</h2>";
echo "<h8>Tunggu 30 Detik Untuk Menampilkan Data Pasien</h8>";
    echo "<table border='1'>";
    echo "<tr>
            <th>No</th>
            <th>No. RM</th>
            <th>Nama Pasien</th>
            <th>No KTP</th>
            <th>Jenis Kelamin</th>
            <th>Alamat</th>
            <th>Tanggal Daftar</th>
          </tr>";
    $no = 1;
    while($row = $result->fetch_assoc()) {
      echo "<tr>";
      echo "<td>" . $no . "</td>";
      echo "<td>" . $row["no_rkm_medis"] . "</td>";
      echo "<td>" . $row["nm_pasien"] . "</td>";
      echo "<td>" . $row["no_ktp"] . "</td>";
      echo "<td>" . $row["jk"] . "</td>";
      echo "<td>" . $row["alamat"] . "</td>";
      echo "<td>" . $row["tgl_daftar"] . "</td>";
      echo "</tr>";
      $no++;
    }
    echo "</table>";
  } else {
    echo "Tidak ada data pasien.";
  }
  ?>



<p>   <p>&nbsp;</p>
   <div class="footer-area">
        <div class="" style="">
            <div class="">
                
            </div>
        </div>




   <div class="footer-area">
        <div class="" style="">
            <div class="">
                
            </div>
        </div>







<p>   <p>&nbsp;</p>







   
    <!-- Footer Area -->
    
            <h1><div class="footer-bottom text-center">
                <ul>
                    <li>
                        <a href="http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/index-dashboard2.php">
<img border="0" src="http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/FILE/BERANDA.png"  height="45" width="45" /></a>
                            <i class=""></i>
                            <p>Beranda</p>
                        </a>
                    </li>
                    <li>
                        <a href="http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/index-dashboard-2-2.html">
<img border="0" src="http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/FILE/SATUSEHAT-INTEGRASI-VERSI-80-2.png"  height="50" width="50" /></a>
                            <i class=""></i>
                            <p>ASKES</p>
                        </a>
                    </li>
                    <li>
                        <a href="http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/WIDGET/NEW/AI-BACA-BARCODE-2">
<img border="0" src="http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/SCANRM2.webp"  height="45" width="45" /></a>
                            <i class=""></i>
                            <p>SCAN RM</p>
                        </a>
                    </li>
                    <li>
                        <a href="http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/index-dashboard-Playstore.html">
<img border="0" src="http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/FILE/PLAYSTORE.png"  height="45" width="45" /></a>
                            <i class=""></i>
                            <p>PLAYSTORE</p>
                        </a>
                    </li>
                    <li>
                        <a href="http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/logout2.php">
<img border="0" src="http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/LOGOUT.webp"  height="45" width="45" /></a>
                            <i class=""></i>
                            <p>LOGOUT</p>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
</div>




</body>
</html>
