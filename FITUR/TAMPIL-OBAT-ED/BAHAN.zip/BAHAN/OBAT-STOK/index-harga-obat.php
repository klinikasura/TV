<?php
session_start();
require_once 'config.php';
require_once 'includes.php';

// Pastikan user sudah login
if (!isset($_SESSION['user_id'])) {
    header('Location: http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/LOG/login.php');
    exit;
}

// Ambil data user berdasarkan ID di session
$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM robot80_data_anggota WHERE id=$user_id";
$result = $mysqli->query($query);
$user = $result->fetch_assoc();

update_user_activity($user_id);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
          <title>Aplikasi RS. Asura</title>
        <link href="http://10.10.20.250/dashboard/download.jpeg" rel="icon" type="image/png"

    <!-- Include file CSS Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Include library Bootstrap Datepicker -->
    <link href="libraries/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet">


 <link rel="stylesheet" href="http://10.10.20.250/dashboard/APPS-ROBOT/assets/css/vendor.css">
    <link rel="stylesheet" href="http://10.10.20.250/dashboard/APPS-ROBOT/assets/css/style.css">
    <link rel="stylesheet" href="http://10.10.20.250/dashboard/APPS-ROBOT/assets/css/responsive.css">

<p>   <p>&nbsp;</p>

<audio autoplay>
    <source src="CEK-HARGA-OBAT.mp3" type="audio/mpeg">
    </audio>


<center>

<?php 
$servername = "10.10.20.250"; 
$username = "root"; 
$password = ""; 
$dbname = "sikdraisyah"; 

// Buat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Tampilkan pilihan bangsal
$query_bangsal = "SELECT kd_bangsal, nm_bangsal FROM bangsal";
$result_bangsal = $conn->query($query_bangsal);
?>
<p>   <p>&nbsp;</p>

<form method="post">
    <select name="kd_bangsal">
        <option value="">Pilih Asal</option>
        <?php while($row_bangsal = $result_bangsal->fetch_assoc()) { ?>
            <option value="<?php echo $row_bangsal['kd_bangsal']; ?>"><?php echo $row_bangsal['nm_bangsal']; ?></option>
        <?php } ?>
    </select>
    <input type="date" name="tgl_awal" placeholder="Tanggal Awal">
    <input type="date" name="tgl_akhir" placeholder="Tanggal Akhir">
    <input type="text" name="nama_obat" placeholder="Nama Obat">
    <button type="submit" name="cari">Cari / Tampil Data</button>
</form>
<div class="table-responsive" style="margin-top: 10px;">
            <table class="table table-bordered">
                <thead>
<?php
if (isset($_POST['cari'])) {
    $kd_bangsal = $_POST['kd_bangsal'];
    $tgl_awal = $_POST['tgl_awal'];
    $tgl_akhir = $_POST['tgl_akhir'];
    $nama_obat = $_POST['nama_obat'];

    $query = "
        SELECT 
            gb.kode_brng, 
            d.nama_brng, 
            d.expire,
            d.ralan,
            d.karyawan,
            gb.kd_bangsal, 
            b.nm_bangsal, 
            gb.stok
        FROM 
            gudangbarang gb
            INNER JOIN databarang d ON gb.kode_brng = d.kode_brng
            INNER JOIN bangsal b ON gb.kd_bangsal = b.kd_bangsal
        WHERE 
            d.status = '1'
    ";

    if (!empty($tgl_awal) && !empty($tgl_akhir)) {
        $query .= " AND d.expire BETWEEN '$tgl_awal' AND '$tgl_akhir'";
    }

    if (!empty($kd_bangsal)) {
        $query .= " AND gb.kd_bangsal = '$kd_bangsal'";
    }

    if (!empty($nama_obat)) {
        $query .= " AND d.nama_brng LIKE '%$nama_obat%'";
    }

    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        echo "<table border='1'>";
        echo "<tr><th>No</th><th>Kode Barang</th><th>Nama Obat & BHP</th><th>Tgl Kadaluarsa</th><th>Harga Ralan</th><th>Harga Karyawan</th><th>Kode Asal</th><th>Nama Asal Stok</th><th>Stok</th></tr>";
        $no = 1;
        while($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $no . "</td>";
            echo "<td>" . $row["kode_brng"] . "</td>";
            echo "<td>" . $row["nama_brng"] . "</td>";
            echo "<td>" . $row["expire"] . "</td>";
            echo "<td>" . $row["ralan"] . "</td>";
            echo "<td>" . $row["karyawan"] . "</td>";
            echo "<td>" . $row["kd_bangsal"] . "</td>";
            echo "<td>" . $row["nm_bangsal"] . "</td>";
            echo "<td>" . $row["stok"] . "</td>";
            echo "</tr>";
            $no++;
        }
        echo "</table>";
        $url_cetak = "print.php?tgl_awal=".$tgl_awal."&tgl_akhir=".$tgl_akhir."&kd_bangsal=".$kd_bangsal."&nama_obat=".$nama_obat;
        echo "<a href='".$url_cetak."' target='_blank'><button>Cetak Laporan</button></a>";
    } else {
        echo "0 hasil";
    }
}

$conn->close();
?>









<p>   <p>&nbsp;</p>
   <div class="footer-area">
        <div class="" style="">
            <div class="">
                
            </div>
        </div>




   <div class="footer-area">
        <div class="" style="">
            <div class="">
                
            </div>
        </div>





<p>   <p>&nbsp;</p>







  <!-- Footer Area -->
    
            <h1><div class="footer-bottom text-center">
                <ul>
                    <li>
                        <a href="http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/index-dashboard2-farmasi.php">
<img border="0" src="http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/FILE/BERANDA.png"  height="45" width="45" /></a>
                            <i class=""></i>
                            <p>Beranda</p>
                        </a>
                    </li>
                    <li>
                        <a href="http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/index-dashboard-2-2.html">
<img border="0" src="http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/FILE/SATUSEHAT-INTEGRASI-VERSI-80-2.png"  height="50" width="50" /></a>
                            <i class=""></i>
                            <p>ASKES</p>
                        </a>
                    </li>
                    <li>
                        <a href="http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/WIDGET/NEW/AI-BACA-BARCODE-2">
<img border="0" src="http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/SCANRM2.webp"  height="45" width="45" /></a>
                            <i class=""></i>
                            <p>SCAN RM</p>
                        </a>
                    </li>
                    <li>
                        <a href="http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/index-dashboard-Playstore.html">
<img border="0" src="http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/FILE/PLAYSTORE.png"  height="45" width="45" /></a>
                            <i class=""></i>
                            <p>PLAYSTORE</p>
                        </a>
                    </li>
                    <li>
                        <a href="http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/logout2.php">
<img border="0" src="http://10.10.20.250/dashboard/APPS-ROBOT/GITHUB/LOGOUT.webp"  height="45" width="45" /></a>
                            <i class=""></i>
                            <p>LOGOUT</p>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
</div>



